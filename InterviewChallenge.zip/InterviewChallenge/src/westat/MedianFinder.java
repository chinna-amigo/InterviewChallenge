package westat;

import java.util.Arrays;

public class MedianFinder {

	private double[] values = new double[0];
	private double[] weights = new double[0];

	public double findMedian(double[] values, double[] weights) {

		this.setValues(values);
		this.setWeights(weights);


		double sumofhiredbydays, midhiredbydays;
		sumofhiredbydays = (Arrays.stream(weights).sum());
		midhiredbydays = sumofhiredbydays / 2;
		System.out.println("The sum of weights is " + sumofhiredbydays);
		System.out.println("midhiredbydays " + midhiredbydays);
		System.out.println("Sorting.....");

		for (int n = 0; n < values.length - 1; n++) {
			System.out.print(values[n] + "...");
			System.out.println(weights[n]);
		}
		System.out.println(" ");
	
		for (int n = 0; n < values.length; n++) {
			for (int m = 0; m < (values.length - 1) - n; m++) {
				if ((values[m] > values[m + 1])) {
					double swapValues = values[m];
					values[m] = values[m + 1];
					values[m + 1] = swapValues;
					double swapWeight = weights[m];
					weights[m] = weights[m + 1];
					weights[m + 1] = swapWeight;
				}
			}
		}
		for (int n = 0; n < values.length; n++) {
			System.out.print(values[n] + "...");
			System.out.println(weights[n]);
		}



		double[] acendingweightArray = new double[values.length];
		double[] decendingweightArray = new double[weights.length];



		int j = 0;
		double temp;
		for (int i = 0; i < weights.length - 1; i++) {

			temp = acendingweightArray[i] + weights[j];

			acendingweightArray[i + 1] = temp;
			j++;
		}

		System.out.println("acendingweightArray" + Arrays.toString(acendingweightArray));

		// decendingweightArray
		decendingweightArray[0] = sumofhiredbydays - weights[0];
		System.out.println("decendingweightArray 0:" + decendingweightArray[0]);
		int k = 0;
		double tempweight;
		for (int i = 0; i < weights.length - 1; i++) {

			tempweight = decendingweightArray[i] - weights[k + 1];

			decendingweightArray[i + 1] = tempweight;
			k++;
		}

		System.out.println("decendingweightArray" + Arrays.toString(decendingweightArray));

		double medianweight = 0;

		// Find the acendingweightArray less or equal to mid hired days
		for (int i = 0; i < acendingweightArray.length; i++) {

			if (acendingweightArray[i] <= midhiredbydays && decendingweightArray[i] <= midhiredbydays) {
				System.out.println("Index value" + i);
				System.out.println("decendingweightArray" + decendingweightArray[i]);
				System.out.println("acendingweightArray" + acendingweightArray[i]);
				System.out.println("Median value:" + values[i]);
				medianweight = values[i];
			}

		}

		return medianweight;
	}

	public double[] getValues() {
		return values;
	}

	public void setValues(double[] values) {
		this.values = values;
	}

	public double[] getWeights() {
		return weights;
	}

	public void setWeights(double[] weights) {
		this.weights = weights;
	}
}