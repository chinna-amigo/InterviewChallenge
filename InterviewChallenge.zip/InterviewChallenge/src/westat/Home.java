package westat;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;

public class Home {
	private DataAccess daobj = new DataAccess();
	private JFrame frmInternetChallenge;
	private JTextField txttotalvalue;
	private JTextField txtAvgorder;
	private JTextField txtAddNewNickName;
	private JTextField textFieldNickName;
	private double total;
	private float average;
	private int selectedProducts;
	private int countoforders;
	private double sumoforders;
	private double avgoforders;
	private String customer_id = null;
	private String customer_name = null;
	private String nickName = null;
	
	private String appendNickname = null;
	private String nick_name = null;
	// private String connectionURL = "jdbc:sqlite:" +
	// this.getClass().getResource("/").getPath()+"Northwind.db";
	private String connectionURL = "jdbc:sqlite::resource:Northwind.db";
	DecimalFormat df = new DecimalFormat("#.00");

	private String productslist =null;
	@SuppressWarnings("rawtypes")
	List product_list = new ArrayList();

	public int getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(int selectedProducts) {
		this.selectedProducts = selectedProducts;
	}


	/**
	 * Launch the application.
	 */

	String home = System.getProperty("user.home");

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Home window = new Home();
					window.frmInternetChallenge.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initialize() {

	

		frmInternetChallenge = new JFrame();
		frmInternetChallenge.setForeground(new Color(0, 153, 255));
		frmInternetChallenge.getContentPane().setBackground(new Color(240, 248, 255));
		frmInternetChallenge.getContentPane().setEnabled(false);
		frmInternetChallenge.setTitle("Interview Challenge");
		frmInternetChallenge.getContentPane().setFont(new Font("Calibri", Font.PLAIN, 35));
		frmInternetChallenge.setBounds(100, 100, 1653, 745);
		frmInternetChallenge.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

		JButton btnAddNewNickname = new JButton("Add new Nickname");
		btnAddNewNickname.setBackground(UIManager.getColor("Button.background"));
		btnAddNewNickname.setBounds(436, 267, 275, 56);
		btnAddNewNickname.setFont(new Font("Calibri", Font.PLAIN, 30));
		btnAddNewNickname.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String textFieldValue = txtAddNewNickName.getText();
				appendNickname = nick_name + "," + textFieldValue;
				System.out.println("nickName:" + nickName);
				System.out.println("appendNickname:" + appendNickname);
				System.out.println("customer_id:" + customer_id);
				textFieldNickName.setText(appendNickname);
				nick_name = appendNickname;
				try {
					
					if (customer_id != null) {

					String updateNickName = "Update customers set nicknames='" + appendNickname + "' where customerid='"
							+ customer_id + "'";
					daobj.updatedb(updateNickName);
					} else
					{	
						JOptionPane.showMessageDialog(null, "Please select the customer!");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}
		});
		frmInternetChallenge.getContentPane().setLayout(null);
				
		
		JComboBox customer_comboBox = new JComboBox();
		customer_comboBox.setBackground(Color.WHITE);
		customer_comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				
				System.out.println("customer_comboBox" + customer_comboBox.getSelectedItem());
				Customer custobj = (Customer) customer_comboBox.getSelectedItem();
				customer_name = custobj.toString();
				customer_id = custobj.getCustomerID();
				System.out.println("Customer Name selected is ..." + customer_name);
				System.out.println("the NickName is !!!!!!!!!!!!" + custobj.getNickNames());
				textFieldNickName.setText(custobj.getNickNames());
				nickName = textFieldNickName.getText();
				System.out.println("nickName  selected is ..." + nickName);
				nick_name = nickName;
				
				productslist=custobj.getProducts();
				
				txttotalvalue.setText(Double.toString(custobj.getTotal()));
			    txtAvgorder.setText(Double.toString(custobj.getAverage()));
				
			   
			    sumoforders=custobj.getTotal();
			    System.out.println("custobj.getTotal"+sumoforders);
			    
			    avgoforders=custobj.getAverage();
			    System.out.println("custobject.getAverage:"+avgoforders);
			    
			    countoforders= custobj.getNumOfOrders();
			    System.out.println("custobject.setNumOfOrders"+countoforders);
			   //total=custobj.getTotal();
		    	//average=Double.toString(custobj.getAverage());
				
			}
			
		});
	
		customer_comboBox.setBounds(35, 63, 675, 49);
		customer_comboBox.setFont(new Font("Calibri", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(customer_comboBox);
		DefaultComboBoxModel mod = new DefaultComboBoxModel(daobj.getCustomerArray());
		customer_comboBox.setModel(mod);

		JLabel lblCustomer = new JLabel("Customer");
		lblCustomer.setBounds(35, 0, 148, 77);
		lblCustomer.setFont(new Font("Calibri", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblCustomer);

		JLabel lblProducts = new JLabel("Products");
		lblProducts.setBounds(759, 1, 134, 77);
		lblProducts.setFont(new Font("Calibri", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblProducts);

		JList list = new JList();
		list.setBounds(0, 0, 0, 0);
		frmInternetChallenge.getContentPane().add(list);

		JLabel lblNicknames = new JLabel("Nick Names");
		lblNicknames.setBounds(35, 135, 361, 37);
		lblNicknames.setFont(new Font("Calibri", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblNicknames);

		textFieldNickName = new JTextField();
		textFieldNickName.setForeground(Color.BLACK);
		textFieldNickName.setBounds(35, 179, 675, 49);
		textFieldNickName.setEditable(false);
		textFieldNickName.setFont(new Font("Calibri", Font.PLAIN, 30));
		textFieldNickName.setColumns(10);
		frmInternetChallenge.getContentPane().add(textFieldNickName);

		txtAddNewNickName = new JTextField();
		txtAddNewNickName.setFont(new Font("Calibri", Font.PLAIN, 30));
		txtAddNewNickName.setBounds(35, 268, 375, 56);
		txtAddNewNickName.setColumns(10);
		frmInternetChallenge.getContentPane().add(txtAddNewNickName);
		frmInternetChallenge.getContentPane().add(btnAddNewNickname);

		JLabel lblTotalValue = new JLabel("Total Value ($)");
		lblTotalValue.setBounds(35, 525, 229, 43);
		lblTotalValue.setFont(new Font("Calibri", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblTotalValue);

		JLabel lblAveragePer = new JLabel("Average $ Per Order");
		lblAveragePer.setBounds(759, 525, 259, 43);
		lblAveragePer.setFont(new Font("Calibri", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblAveragePer);

		JButton btnExportToHtml = new JButton("Export to HTML");
		UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18)));
		btnExportToHtml.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					if (customer_id != null) {
						exportToHTML();
						JOptionPane.showMessageDialog(btnExportToHtml,
								"Please find the file here:" + home + "\\" + "Downloads" + "\\" + "Export.html",
								"Downloaded", 1);
					} else {

						JOptionPane.showMessageDialog(null, "Please select the customer!");
					}

				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		});
		btnExportToHtml.setBounds(1277, 518, 259, 56);
		btnExportToHtml.setFont(new Font("Calibri", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(btnExportToHtml);

		txttotalvalue = new JTextField();
		txttotalvalue.setBounds(35, 581, 246, 49);
		txttotalvalue.setEditable(false);
		txttotalvalue.setFont(new Font("Calibri", Font.PLAIN, 35));
		txttotalvalue.setColumns(10);
		
		frmInternetChallenge.getContentPane().add(txttotalvalue);
	//	total=Double.parseDouble(txttotalvalue.getSelectedText());
		
		txtAvgorder = new JTextField();
		txtAvgorder.setBounds(759, 581, 259, 49);
		txtAvgorder.setFont(new Font("Calibri", Font.PLAIN, 35));
		txtAvgorder.setEditable(false);
		txtAvgorder.setColumns(10);
		
		frmInternetChallenge.getContentPane().add(txtAvgorder);
		//average=Double.parseDouble(txtAvgorder.getSelectedText());

		JButton btnExportToCSV = new JButton("Export to CSV");
		btnExportToCSV.setBounds(1277, 579, 259, 56);
		btnExportToCSV.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (customer_id != null) {
				exportToCSV();
				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18)));

				JOptionPane.showMessageDialog(btnExportToCSV,
						"Please find the file here:" + home + "\\" + "Downloads" + "\\" + "Export.csv", "Downloaded",
						1);
				} else {
					JOptionPane.showMessageDialog(null, "Please select the customer!");
				}
				}
			

		});
		btnExportToCSV.setFont(new Font("Calibri", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(btnExportToCSV);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(759, 63, 777, 387);
		frmInternetChallenge.getContentPane().add(scrollPane);

		Box verticalBoxProductList = Box.createVerticalBox();
		verticalBoxProductList.setForeground(Color.WHITE);
		// verticalBoxProductList.setForeground(Color.WHITE);
		verticalBoxProductList.setBackground(UIManager.getColor("Button.highlight"));
		scrollPane.setViewportView(verticalBoxProductList);
		verticalBoxProductList.setFont(new Font("Calibri", Font.PLAIN, 30));
		verticalBoxProductList.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		System.out.println("The Size of ProductArray is " + daobj.getProductArray().length);
		
		for (int i = 0; i < daobj.getProductArray().length; i++) {
			
			JCheckBox chckbxProduct = new JCheckBox();
			chckbxProduct.setSelected(false);
			chckbxProduct.setFont(new Font("Calibri", Font.PLAIN, 30));
			chckbxProduct.setText(daobj.getProductArray()[i].getProductName());
			chckbxProduct.setName(daobj.getProductArray()[i].getUnitPrice());
			

				chckbxProduct.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					
					if (customer_id == null) {

						JOptionPane.showMessageDialog(null, "Please select the customer!");
						} else
						{	
							
						
					if (chckbxProduct.isSelected()) {
						//total=total+sumoforders;
						total = Double.parseDouble(txttotalvalue.getText())+ Double.valueOf(chckbxProduct.getName());
						selectedProducts = selectedProducts + 1;
						product_list.add(chckbxProduct.getText());
						System.out.println("product_list" + product_list);
					}
					if (!chckbxProduct.isSelected()) {
						total = total - Double.valueOf(chckbxProduct.getName());
						selectedProducts = selectedProducts - 1;
					}
					txttotalvalue.setText(String.valueOf(total));
					
					average=(float) (total / (selectedProducts+countoforders));
					
					
					txtAvgorder.setText(String.valueOf(df.format(average)));
					System.out.println("the total is " + total);
					System.out.println("Average:" + average);
				}}
			});
			
			verticalBoxProductList.add(chckbxProduct);
		
		}

	}

	public void exportToCSV() {

		PrintWriter writer = null;

		try {
			writer = new PrintWriter(home + "/Downloads/" + "Export.csv", "UTF-8");

		
			writer.println("Customer,NickName,Products,Total,Avg");
			writer.print(customer_name + "," + "\"" + nick_name + "\"" + "," + "\"" + productslist + "\"" + ","
					+ total + "," + average);

		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			writer.close();
		}
	}

	public void exportToHTML() throws SQLException, ClassNotFoundException {

		PrintWriter writer = null;

		Connection connection;
		ResultSet rs;

	
		try {

			Class.forName("org.sqlite.JDBC");

			connection = DriverManager.getConnection(connectionURL, "root", "root");

			System.out.println("customer_id:" + customer_id);

			String ordersql = "select customer,nicknames,products,Total,Average,Employeename,hiredfordays,employeeid "
					+ "from SaleByEmployees where customerid=" + "'" + customer_id + "'";

			System.out.println("ordersql:" + ordersql);
			java.sql.Statement stmt = connection.createStatement();

			rs = stmt.executeQuery(ordersql);

			List<Object> customerlist = new ArrayList<>();
			List<Object> nicknameslist = new ArrayList<>();
			List<Object> productslist = new ArrayList<>();
			List<Object> employeelist = new ArrayList<>();
			List<Object> totallist = new ArrayList<>();
			List<Object> empidlist = new ArrayList<>();

			double[] valuesArray = new double[9];
			double[] weightsArray = new double[9];

			int i = 0;
			while (rs.next()) {
				customerlist.add(rs.getString(1));

				nicknameslist.add(rs.getString(2));

				productslist.add(rs.getString(3));

				totallist.add(rs.getString(4));

				valuesArray[i] = Double.parseDouble(rs.getString(5));

				employeelist.add(rs.getString(6));

				weightsArray[i] = Double.parseDouble(rs.getString(7));

				empidlist.add(rs.getString(8));

				// writer.println("<td style=\"display:none;\">" +
				// empidlist.get(i)+ "</td></tr>");

				i++;
			}

			System.out.println(i);

			writer = new PrintWriter(home + "/Downloads/" + "Export.html", "UTF-8");
			writer.println("<!DOCTYPE html>");
			writer.println("<html>");
			writer.println("<head>");

			writer.println("<script src=\"https://code.jquery.com/jquery-2.2.4.js\">" + "</script>");
			writer.println("<script src=\"script.js\">" + "</script>");

			writer.println("<script>"
					+ "$(document).ready(function($) {$('table').show(); $('#mySelector').change(function() {"
					+ " $('table').show(); var selection = $(this).val(); var dataset = $('#myTable tbody').find('tr'); dataset.show();"
					+ " dataset.filter(function(index, item) {return $(item).find('td:first-child').text().split(',').indexOf(selection) === -1;"
					+ " }).hide(); });});");
			writer.println("</script>");
			writer.println("<style>	table { border-collapse: collapse;  width: 100%;}"
					+ "th,td {  padding: 8px;  text-align: left; border-bottom: 1px solid #ddd;}.styled-select.slate {height: 34px;  width: 240px;}");
			writer.println("</style>");
			writer.println("</head>");
			writer.println("<body>");
			writer.println("<select id='mySelector' class=\"styled-select slate\">");
			writer.println("<option selected=\"selected\">All</option>");
			int index = 1;
			Enumeration<Object> e = Collections.enumeration(employeelist);
			while (e.hasMoreElements()) {
				writer.println("<option value='" + index + "'>" + e.nextElement() + "</option>");
				index++;
			}
			writer.println("</select>");
			writer.print("Current Date: 2027-01-01");

			writer.println("<table id='myTable'>");
			writer.println("<thead><tr>");
			writer.println("<th style=\"visibility:hidden;\">ID</th>");
			writer.println("<th>Customer Name</th>");
			writer.println("<th>Nick Names</th>");
			writer.println("<th>Products</th>");
			writer.println("<th>Total($)</th>");
			writer.println("<th>Average($)</th>");
			writer.println("<th>By Employee</th>");
			writer.println("<th>Hired for Days</th>");
			// writer.println("<th align=\"left\"
			// style=\"display:none;\">Employee ID</th>");
			writer.println("</tr></thead>");
			writer.println("<tbody>");
			int m = 1;
			for (int k = 0; k < customerlist.size(); k++) {

				writer.println("<tr>");
				writer.println("<td style=\"visibility:hidden;\">" + m + "</td>");
				writer.println("<td>" + customerlist.get(k) + "</td>");
				writer.println("<td>" + nicknameslist.get(k) + "</td>");
				writer.println("<td>" + productslist.get(k) + "</td>");
				writer.println("<td>" + totallist.get(k) + "</td>");
				writer.println("<td>" + valuesArray[k] + "</td>");// average
				writer.println("<td>" + employeelist.get(k) + "</td>");
				writer.println("<td>" + df.format(weightsArray[k]) + "</td>");// Hired
																				// by
																				// days
				m++;
			}
			writer.println("</tr></tbody>");
			writer.println("</table>");
			// values={619, 511.37, 409.69, 467.92, 510.78, 414.35, 502.07,
			// 486.26, 440.31};
			// weights={975, 870, 1005, 608, 441, 441, 364, 302, 47};
			double[] values = new double[i];
			double[] weights = new double[i];
			for (int k = 0; k < values.length; k++) {
				values[k] = valuesArray[k];
				weights[k] = weightsArray[k];
			}

			MedianFinder median = new MedianFinder();
			writer.println("Weighted median(Avg$ Weighted by hired by days:" + median.findMedian(values, weights));
			
			writer.println("</body>");
			writer.println("</html>");

		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			writer.close();
		}
	}
}
