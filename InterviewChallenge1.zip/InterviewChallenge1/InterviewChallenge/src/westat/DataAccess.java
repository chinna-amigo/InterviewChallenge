package westat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DataAccess {
	private Product[] productArray;
	private Customer[] customerArray;
	private String connectionURL = "jdbc:sqlite::resource:Northwind.db";
	
	public Product[] getProductArray() {
		
		Product[] productArray = new Product[77];
		ResultSet rs=this.querydb("select * from products");
		int i = 0;
		try {
			while (rs.next()) {

				// Add records into data list
				// dataList.add(rs.getString("ProductId"));
				Product productobj = new Product();
				productobj.setProductID(rs.getString("ProductId"));
				productobj.setProductName(rs.getString("ProductName"));
				productobj.setQuantityPerUnit(rs.getString("QuantityPerUnit"));
				productobj.setUnitPrice(rs.getString("UnitPrice"));
				productArray[i++] = productobj;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return productArray;
	}

	public void setProductArray(Product[] productArray) {
		this.productArray = productArray;
	}

	public Customer[] getCustomerArray() {
		Customer[] customerArray = new Customer[93];
		ResultSet rs=this.querydb("select * from customers");
		int i = 0;
		try {
			while (rs.next()) {

				// Add records into data list
				// custlist.add(rs.getString("CompanyName"));
				Customer custobject = new Customer();
				custobject.setCustomerID(rs.getString("CustomerID"));
				custobject.setContactName(rs.getString("CompanyName"));
				custobject.setNickNames(rs.getString("NickNames"));
				customerArray[i++] = custobject;
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customerArray;
	}

	public void setCustomerArray(Customer[] customerArray) {
		this.customerArray = customerArray;
	}

	
	public ResultSet querydb(String query){
		Connection connection;
		ResultSet rs=null;
		try {
			// Load the database driver
			Class.forName("org.sqlite.JDBC");
			// Get a Connection to the database
			connection = DriverManager.getConnection(connectionURL, "root", "root");
			// Select the data from the database
			// s.executeQuery (sql);
			java.sql.Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
			}
			catch(Exception e){e.printStackTrace();}
			return rs;		
	}
	
	
	public void updatedb(String query){
		Connection connection;
		try {
			// Load the database driver
			Class.forName("org.sqlite.JDBC");
			// Get a Connection to the database
			connection = DriverManager.getConnection(connectionURL, "root", "root");
			PreparedStatement ps = connection.prepareStatement(query);
			ps.executeUpdate();
			ps.close();
			}
			catch(Exception e){e.printStackTrace();}
				
	}
}
