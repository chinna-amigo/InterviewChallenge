package westat;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.beans.Statement;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;

import java.awt.Panel;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.Box;

public class Home {

	private JFrame frmInternetChallenge;
	private JTextField txttotalvalue;
	private JTextField txtAvgorder;
	private JTextField txtAddNewName;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	
	String home = System.getProperty("user.home");
		
	private List productList,customerList;
	
	
	public List getProductList() {
		return productList;
	}

	public void setProductList(List productList) {
		this.productList = productList;
	}

	public List getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List customerList) {
		this.customerList = customerList;
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frmInternetChallenge.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		connect();
		
		frmInternetChallenge = new JFrame();
		frmInternetChallenge.setTitle("Interview Challenge");
		frmInternetChallenge.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.setBounds(100, 100, 1653, 745);
		frmInternetChallenge.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		
	
	  System.out.println(this.getCustomerList().size());
		
		JButton btnAddNewNickname = new JButton("Add new Nickname");
		btnAddNewNickname.setBounds(401, 268, 378, 68);
		btnAddNewNickname.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnAddNewNickname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		frmInternetChallenge.getContentPane().setLayout(null);
		
		JComboBox customer_comboBox = new JComboBox();
		customer_comboBox.setBounds(35, 63, 744, 40);
		customer_comboBox.setFont(new Font("Tahoma", Font.PLAIN, 28));
		frmInternetChallenge.getContentPane().add(customer_comboBox);
		
		for(int i=0; i< this.getCustomerList().size();i++)
		{
			customer_comboBox.addItem(this.getCustomerList().get(i));
		}
		
		
		JLabel lblCustomer = new JLabel("Customer");
		lblCustomer.setBounds(35, 0, 148, 77);
		lblCustomer.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblCustomer);
		
		JLabel lblProducts = new JLabel("Products");
		lblProducts.setBounds(819, 0, 134, 77);
		lblProducts.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblProducts);
		
		JList list = new JList();
		list.setBounds(0, 0, 0, 0);
		frmInternetChallenge.getContentPane().add(list);
		
		JLabel lblNicknames = new JLabel("NickNames");
		lblNicknames.setBounds(35, 108, 361, 37);
		lblNicknames.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblNicknames);
		
		textField = new JTextField();
		textField.setBounds(35, 173, 744, 49);
		textField.setEditable(false);
		textField.setFont(new Font("Tahoma", Font.PLAIN, 35));
		textField.setColumns(10);
		frmInternetChallenge.getContentPane().add(textField);
		
		txtAddNewName = new JTextField();
		txtAddNewName.setBounds(35, 268, 361, 68);
		txtAddNewName.setColumns(10);
		frmInternetChallenge.getContentPane().add(txtAddNewName);
		frmInternetChallenge.getContentPane().add(btnAddNewNickname);
		
		JLabel lblTotalValue = new JLabel("Total Value ($)");
		lblTotalValue.setBounds(35, 467, 229, 43);
		lblTotalValue.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblTotalValue);
		
		JLabel lblAveragePer = new JLabel("Average $ Per Order");
		lblAveragePer.setBounds(784, 467, 314, 43);
		lblAveragePer.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblAveragePer);
		
		JButton btnExportToHtml = new JButton("Export to HTML");
		btnExportToHtml.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
	exportToHTML();
				
				//JOptionPane.showMessageDialog(btnExportToHtml, "Please find the file here \"D:"+"\\"+"workspace"+"\\"+"TestingAWT"+"\\"+"resource"+"\\"+"Export.html"); 
				
				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18)));   
				JOptionPane.showMessageDialog(btnExportToHtml, "Please find the file here:"+home+"\\"+"Downloads"+"\\"+"Export.html","Downloaded",1);  
			
			}
			
		});
		btnExportToHtml.setBounds(1188, 467, 388, 63);
		btnExportToHtml.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(btnExportToHtml);
		
		txttotalvalue = new JTextField();
		txttotalvalue.setBounds(35, 535, 361, 49);
		txttotalvalue.setEditable(false);
		txttotalvalue.setFont(new Font("Tahoma", Font.PLAIN, 35));
		txttotalvalue.setColumns(10);
		frmInternetChallenge.getContentPane().add(txttotalvalue);
		
		txtAvgorder = new JTextField();
		txtAvgorder.setBounds(784, 535, 366, 49);
		txtAvgorder.setFont(new Font("Tahoma", Font.PLAIN, 35));
		txtAvgorder.setEditable(false);
		txtAvgorder.setColumns(10);
		frmInternetChallenge.getContentPane().add(txtAvgorder);
		
		JButton btnExportToCSV = new JButton("Export to CSV");
		btnExportToCSV.setBounds(1188, 535, 388, 69);
		btnExportToCSV.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
	exportToCSV();
				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18))); 
				
				JOptionPane.showMessageDialog(btnExportToCSV, "Please find the file here:"+home+"\\"+"Downloads"+"\\"+"Export.csv","Downloaded",1);  
				       
							
			}
			
		});
		btnExportToCSV.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(btnExportToCSV);
		
		Box verticalBoxProductList = Box.createVerticalBox();
		verticalBoxProductList.setFont(new Font("Tahoma", Font.PLAIN, 30));
		verticalBoxProductList.setBorder(new LineBorder(new Color(0, 0, 0)));
		verticalBoxProductList.setBounds(819, 63, 757, 387);
		
		
		
		//int j=0;
		for(int i=0; i< this.getProductList().size();i++)
		{
		
		JCheckBox chckbxProduct = new JCheckBox(this.getProductList().get(i).toString());
		chckbxProduct.setFont(new Font("Tahoma", Font.PLAIN, 30));
	    //chckbxProduct.setBounds(887, 100+j, 143, 29);
	    
		//frame.getContentPane().add(chckbxProduct);
		
	    verticalBoxProductList.add(chckbxProduct);
		
		//j=j+25;
		}
		
		//JScrollPane scrollPane = new JScrollPane(verticalBox,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER,); 
		//scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		frmInternetChallenge.getContentPane().add(verticalBoxProductList);

	}
	
	public void connect()
	
	{
		
		//String connectionURL = "jdbc:sqlite:" + this.getResource("/").getPath() + "/Northwind.db";
		String connectionURL = "jdbc:sqlite:C:/devops/sqlite/Northwind.db";
        Connection connection ;
        ResultSet rs;

        List custlist=new ArrayList();
        List prodlist=new ArrayList();
       

        try {

            // Load the database driver
            Class.forName("org.sqlite.JDBC");

            // Get a Connection to the database
            //connection = DriverManager.getConnection(connectionURL, "root", "root"); 
            connection = DriverManager.getConnection(connectionURL, "root", "root");
            //Select the data from the database

            // s.executeQuery (sql);
            java.sql.Statement stmt = connection.createStatement();
            String selectquery = "select * from products";

            rs = stmt.executeQuery(selectquery);

            while (rs.next()) {

                //Add records into data list
                // dataList.add(rs.getString("ProductId"));
            	prodlist.add(rs.getString("ProductName"));
                

            }
            System.out.println("Produclist:"+prodlist);
            
            String sqlCustomer = "select CompanyName,ContactName from customers";

            rs = stmt.executeQuery(sqlCustomer);

            while (rs.next()) {

                //Add records into data list
            	//custlist.add(rs.getString("CompanyName"));
            	custlist.add(rs.getString("ContactName")); 
            }
            System.out.println("custlist:"+custlist);
            
            this.setCustomerList(custlist);
            this.setProductList(prodlist);
            //System.out.println(" Customer and Product added"+this.getCustomerList().size()+this.getProductList().size());

            rs.close();
        } catch (Exception e) {

            System.out.println("Exception is ;" + e);

        }
	}
	
	public void exportToHTML() {

		PrintWriter writer = null;
		try {
			writer = new PrintWriter(home+"/Downloads/"+"Export.html", "UTF-8");
			writer.println("<!DOCTYPE html>");
			writer.println("<html>");
			writer.println("<head>");
			writer.println("</head>");
			writer.println("<body>");
			writer.println("<table>");
			writer.println("<tr>");
			writer.println("<th align=\"left\">Customer Name</th>");
			writer.println("</tr>");
			for (int i = 0; i < this.getCustomerList().size(); i++) {
				writer.println("<tr><td>");
				writer.println(this.getCustomerList().get(i));
				writer.println("</td></tr>");
			}

			writer.println("</body>");
			writer.println("</body>");
			writer.println("</html>");
			
		    

		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
finally{
		writer.close();
}
			}

	public void exportToCSV(){
		
	PrintWriter writer = null;
	
	try {
		writer = new PrintWriter(home+"/Downloads/"+"Export.csv", "UTF-8");
		
	
		writer.println("Customer");
		writer.println("NickName");
		writer.println("Products");
		writer.println("Total");
		writer.println("Avg");
		
		for (int i = 0; i <this.getCustomerList().size(); i++) {
			
			writer.println(this.getCustomerList().get(i));
			
		}


	} catch (FileNotFoundException | UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
	writer.close();
	}
}
	
}

