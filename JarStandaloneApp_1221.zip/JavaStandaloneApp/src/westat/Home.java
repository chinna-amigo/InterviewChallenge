package westat;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.beans.Statement;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JTextPane;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;

import java.awt.Panel;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;

public class Home {

	private JFrame frmInternetChallenge;
	private JTextField txttotalvalue;
	private JTextField txtAvgorder;
	private JTextField txtAddNewName;
	private JTextField textField;
	private float total;
	private int selectedProducts;
	public int getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(int selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	/**
	 * Launch the application.
	 */
	
	String home = System.getProperty("user.home");
		
	private Product[] productArray;
	public Product[] getProductArray() {
		return productArray;
	}

	public void setProductArray(Product[] productArray) {
		this.productArray = productArray;
	}

	private Customer[] customerArray;
	

	public Customer[] getCustomerArray() {
		return customerArray;
	}

	public void setCustomerArray(Customer[] customerArray) {
		this.customerArray = customerArray;
	}

	



	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frmInternetChallenge.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		connect();
		
		frmInternetChallenge = new JFrame();
		frmInternetChallenge.setTitle("Interview Challenge");
		frmInternetChallenge.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.setBounds(100, 100, 1653, 745);
		frmInternetChallenge.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		
	
	  System.out.println(this.getCustomerArray().length);
		
		JButton btnAddNewNickname = new JButton("Add new Nickname");
		btnAddNewNickname.setBounds(401, 268, 378, 68);
		btnAddNewNickname.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnAddNewNickname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		frmInternetChallenge.getContentPane().setLayout(null);
		
		JComboBox customer_comboBox = new JComboBox();
		customer_comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("I am watching !!!!!!!!!!!!"+customer_comboBox.getSelectedItem());
				Customer custobj=(Customer)customer_comboBox.getSelectedItem();
				System.out.println("the NickName is !!!!!!!!!!!!"+custobj.getNickNames());
				textField.setText(custobj.getNickNames());
				
			}
		});
		customer_comboBox.setBounds(35, 63, 645, 40);
		customer_comboBox.setFont(new Font("Tahoma", Font.PLAIN, 28));
		frmInternetChallenge.getContentPane().add(customer_comboBox);
		DefaultComboBoxModel mod=new DefaultComboBoxModel(this.getCustomerArray());
		customer_comboBox.setModel(mod);
		
		
		JLabel lblCustomer = new JLabel("Customer");
		lblCustomer.setBounds(35, 0, 148, 77);
		lblCustomer.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblCustomer);
		
		JLabel lblProducts = new JLabel("Products");
		lblProducts.setBounds(819, 0, 134, 77);
		lblProducts.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblProducts);
		
		JList list = new JList();
		list.setBounds(0, 0, 0, 0);
		frmInternetChallenge.getContentPane().add(list);
		
		JLabel lblNicknames = new JLabel("NickNames");
		lblNicknames.setBounds(35, 108, 361, 37);
		lblNicknames.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblNicknames);
		
		textField = new JTextField();
		textField.setBounds(35, 173, 744, 49);
		textField.setEditable(false);
		textField.setFont(new Font("Tahoma", Font.PLAIN, 35));
		textField.setColumns(10);
		frmInternetChallenge.getContentPane().add(textField);
		
		txtAddNewName = new JTextField();
		txtAddNewName.setBounds(35, 268, 361, 68);
		txtAddNewName.setColumns(10);
		frmInternetChallenge.getContentPane().add(txtAddNewName);
		frmInternetChallenge.getContentPane().add(btnAddNewNickname);
		
		JLabel lblTotalValue = new JLabel("Total Value ($)");
		lblTotalValue.setBounds(35, 467, 229, 43);
		lblTotalValue.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblTotalValue);
		
		JLabel lblAveragePer = new JLabel("Average $ Per Order");
		lblAveragePer.setBounds(784, 467, 314, 43);
		lblAveragePer.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblAveragePer);
		
		JButton btnExportToHtml = new JButton("Export to HTML");
		btnExportToHtml.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exportToHTML();
				
				//JOptionPane.showMessageDialog(btnExportToHtml, "Please find the file here \"D:"+"\\"+"workspace"+"\\"+"TestingAWT"+"\\"+"resource"+"\\"+"Export.html"); 
				
				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18)));   
				JOptionPane.showMessageDialog(btnExportToHtml, "Please find the file here:"+home+"\\"+"Downloads"+"\\"+"Export.html","Downloaded",1);  
			
			}
			
		});
		btnExportToHtml.setBounds(1184, 521, 148, 63);
		btnExportToHtml.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmInternetChallenge.getContentPane().add(btnExportToHtml);
		
		txttotalvalue = new JTextField();
		txttotalvalue.setBounds(35, 535, 361, 49);
		txttotalvalue.setEditable(false);
		txttotalvalue.setFont(new Font("Tahoma", Font.PLAIN, 35));
		txttotalvalue.setColumns(10);
		frmInternetChallenge.getContentPane().add(txttotalvalue);
		
		txtAvgorder = new JTextField();
		txtAvgorder.setBounds(784, 535, 366, 49);
		txtAvgorder.setFont(new Font("Tahoma", Font.PLAIN, 35));
		txtAvgorder.setEditable(false);
		txtAvgorder.setColumns(10);
		frmInternetChallenge.getContentPane().add(txtAvgorder);
		
		JButton btnExportToCSV = new JButton("Export to CSV");
		btnExportToCSV.setBounds(1183, 592, 148, 69);
		btnExportToCSV.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
	exportToCSV();
				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18))); 
				
				JOptionPane.showMessageDialog(btnExportToCSV, "Please find the file here:"+home+"\\"+"Downloads"+"\\"+"Export.csv","Downloaded",1);  
				       
							
			}
			
		});
		btnExportToCSV.setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmInternetChallenge.getContentPane().add(btnExportToCSV);
		
		
		
		
		 CheckboxGroup cbg = new CheckboxGroup();
		 frmInternetChallenge.getContentPane().add(new Checkbox("one", cbg, true));
		 frmInternetChallenge.getContentPane().add(new Checkbox("two", cbg, false));
		 frmInternetChallenge.getContentPane().add(new Checkbox("three", cbg, false));
		 
		 Box verticalBoxProductList = Box.createVerticalBox();
		 verticalBoxProductList.setBounds(829, 73, 388, 362);
		 frmInternetChallenge.getContentPane().add(verticalBoxProductList);
		 verticalBoxProductList.setFont(new Font("Tahoma", Font.PLAIN, 30));
		 verticalBoxProductList.setBorder(new LineBorder(new Color(0, 0, 0)));
		 JScrollPane scrollPane = new JScrollPane();
		 scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		 scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPane.setBounds(819, 63, 401, 387);
			frmInternetChallenge.getContentPane().add(scrollPane);
		//int j=0;
		 System.out.println("The Size of ProductArray is "+this.getProductArray().length);
		 
		for(int i=0; i< this.getProductArray().length;i++)
		{
		//System.out.println("The ProductID is ********* "+this.getProductArray()[i].getProduc());
		JCheckBox chckbxProduct = new JCheckBox();
		chckbxProduct.setFont(new Font("Tahoma", Font.PLAIN, 30));
		chckbxProduct.setText(this.getProductArray()[i].getProductName());
		chckbxProduct.setName(this.getProductArray()[i].getUnitPrice());
	    //chckbxProduct.setBounds(887, 100+j, 143, 29);
		//chckbxProduct.add
		//frame.getContentPane().add(chckbxProduct);
		//cbg.add(chckbxProduct);
		chckbxProduct.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(chckbxProduct.isSelected())
				{
					total=total+Float.valueOf(chckbxProduct.getName());
					selectedProducts=selectedProducts+1;
					}
				if(!chckbxProduct.isSelected()){
				total=total-Float.valueOf(chckbxProduct.getName());
				selectedProducts=selectedProducts-1;
				}
				txttotalvalue.setText(String.valueOf(total));
				txtAvgorder.setText(String.valueOf(total/selectedProducts));
				System.out.println("the total is "+total);
			}
		});
	    verticalBoxProductList.add(chckbxProduct);
	    //verticalBoxProductList.add(new Checkbox(this.getProductList().get(i).toString(), cbg, true));
	    //frmInternetChallenge.getContentPane().add(new Checkbox(this.getProductList().get(i).toString(), cbg, true));
		//j=j+25;
		}
		
		

	}
	
	public void connect()
	
	{
		
		//String connectionURL = "jdbc:sqlite:" + this.getResource("/").getPath() + "/Northwind.db";
		String connectionURL = "jdbc:sqlite:D:\\Downloads\\JavaStandaloneApp\\JavaStandaloneApp\\Northwind.db";
        Connection connection ;
        ResultSet rs;

        List custlist=new ArrayList();
        List prodlist=new ArrayList();
        
        Customer[] custArray=new Customer[93];
        Product [] productArray=new Product[77];
       

        try {

            // Load the database driver
            Class.forName("org.sqlite.JDBC");
            // Get a Connection to the database
            //connection = DriverManager.getConnection(connectionURL, "root", "root"); 
            connection = DriverManager.getConnection(connectionURL, "root", "root");
            //Select the data from the database
            // s.executeQuery (sql);
            java.sql.Statement stmt = connection.createStatement();
            String selectquery = "select * from products";

            rs = stmt.executeQuery(selectquery);
            int i=0;
            while (rs.next()) {

                //Add records into data list
                // dataList.add(rs.getString("ProductId"));
            	Product productobj=new Product();
            	productobj.setProductID(rs.getString("ProductId"));
            	productobj.setProductName(rs.getString("ProductName"));
            	productobj.setQuantityPerUnit(rs.getString("QuantityPerUnit"));
            	productobj.setUnitPrice(rs.getString("UnitPrice"));
                productArray[i++]=productobj;
                

            }
            System.out.println("Produclist:"+prodlist);
            
            String sqlCustomer = "select * from customers";

            rs = stmt.executeQuery(sqlCustomer);
           // Customer[] custArray=new Customer[rs];
            i=0;
            while (rs.next()) {

                //Add records into data list
            	//custlist.add(rs.getString("CompanyName"));
            	Customer custobject=new Customer();
            	custobject.setCustomerID(rs.getString("CustomerID"));
            	custobject.setContactName(rs.getString("ContactName"));
            	custobject.setNickNames(rs.getString("CompanyName"));
            	
            	custArray[i++]=custobject;          	
            }
            
            System.out.println("custlist:"+custlist);
            //this.setCustomerList(custlist);
            this.setCustomerArray(custArray);
            this.setProductArray(productArray);
            //System.out.println(" Customer and Product added"+this.getCustomerList().size()+this.getProductList().size());

            rs.close();
        } catch (Exception e) {

            System.out.println("Exception is ;" + e);

        }
	}
	
	public void exportToHTML() {

		PrintWriter writer = null;
		try {
			writer = new PrintWriter(home+"/Downloads/"+"Export.html", "UTF-8");
			writer.println("<!DOCTYPE html>");
			writer.println("<html>");
			writer.println("<head>");
			writer.println("</head>");
			writer.println("<body>");
			writer.println("<table>");
			writer.println("<tr>");
			writer.println("<th align=\"left\">Customer Name</th>");
			writer.println("</tr>");
			for (int i = 0; i < this.getCustomerArray().length; i++) {
				writer.println("<tr><td>");
				writer.println(this.getCustomerArray().length);
				writer.println("</td></tr>");
			}

			writer.println("</body>");
			writer.println("</body>");
			writer.println("</html>");
			
		    

		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
finally{
		writer.close();
}
			}

	public void exportToCSV(){
		
	PrintWriter writer = null;
	
	try {
		writer = new PrintWriter(home+"/Downloads/"+"Export.csv", "UTF-8");
		
	
		writer.println("Customer");
		writer.println("NickName");
		writer.println("Products");
		writer.println("Total");
		writer.println("Avg");
		
		for (int i = 0; i <this.getCustomerArray().length; i++) {
			
			writer.println(this.getCustomerArray()[i]);
			
		}


	} catch (FileNotFoundException | UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
	writer.close();
	}
}
	
}

